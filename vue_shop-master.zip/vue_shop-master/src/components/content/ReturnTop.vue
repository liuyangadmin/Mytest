<template>
    <div>
        <!-- 回到顶部 -->
        <img src="@assets/img/common/top.png"/>>
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="less" scoped>
    
</style>